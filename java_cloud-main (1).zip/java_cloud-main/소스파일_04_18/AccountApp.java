
public class AccountApp {

	public static void main(String[] args) {
		
		//�ν��Ͻ� ����
		Account account1 = new Account("1111", "�ϱ浿", "1234", 1000);
		
		System.out.println(account1.getAccountNumber());

	}

}
