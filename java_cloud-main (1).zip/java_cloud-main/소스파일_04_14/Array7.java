
public class Array7 {

	public static void main(String[] args) {
		//�迭 �ʱ�ȭ
		int[][] scores = {{100, 100, 100, 100, 100},
				          {90, 90, 90, 90, 90},
				          {80, 80, 80, 80, 80}};
		
		
		//�迭 ��� ���� ��� (Enhanced for��)
		for (int[] temp1 : scores) {
			for (int temp2 : temp1) {
				System.out.printf("%d\t", temp2);
			}
			System.out.println();
		}		
	}
}
