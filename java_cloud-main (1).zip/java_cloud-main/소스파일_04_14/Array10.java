
public class Array10 {

	public static void main(String[] args) {
		
		//�迭 �ʱ�ȭ
		int[][] scores = {{100,50,90,100,90},
				          {90,90,100,50,45},
				          {100,80,70,60,50}};
		
		//for���� �̿��Ͽ� �л��� ������ ����Ͻÿ�.
		for(int i = 0; i < scores.length; i++) {
			int total = 0;
			for (int j = 0; j < scores[i].length; j++) {
				total += scores[i][j];				
				System.out.printf("%d\t", scores[i][j]);
			}			
			double average = (double)total / scores[i].length;
			System.out.printf("%d\t %.2f%n", total, average);
		}		
	}
}

//total 0 + 100 + 50 + 90 + 100 + 90



