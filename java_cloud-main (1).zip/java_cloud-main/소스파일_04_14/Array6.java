import java.util.Iterator;

public class Array6 {

	public static void main(String[] args) {
		
		// �迭 ���� �� ����
		int[][] scores = new int[3][5];  //�л���, �����
		
		System.out.printf("scores : %s%n", scores);
		
		for (int i = 0; i < scores.length; i++) {
			System.out.printf("scores[%d] : %s%n", i, scores[i]);
		}
		
		//�迭 ��ҿ� �� �Ҵ�
		scores[0][0] = 100;
		scores[0][1] = 100;
		scores[0][2] = 100;
		scores[0][3] = 100;		
		scores[0][4] = 100;
		
		scores[1][0] = 90;
		scores[1][1] = 90;
		scores[1][2] = 90;
		scores[1][3] = 90;		
		scores[1][4] = 90;
		
		scores[2][0] = 80;
		scores[2][1] = 80;
		scores[2][2] = 80;
		scores[2][3] = 80;		
		scores[2][4] = 80;
		
		//�迭 ��� ���� ���
		for (int i = 0; i < scores.length; i++) {
			for (int j = 0; j < scores[i].length; j++) {
				System.out.printf("%d\t", scores[i][j]);
			}
			System.out.println();		
		}
		
	}

}












