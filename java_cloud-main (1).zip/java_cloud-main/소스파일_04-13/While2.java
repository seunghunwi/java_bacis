import java.util.Scanner;

//while���� ���� ����

public class While2 {
	public static void main(String[] args) {
		
		System.out.print("Enter input data ");
		
		Scanner scan = new Scanner(System.in);
		
		while (scan.hasNext()) {
			String token = scan.next();
			System.out.printf("%s%n", token);
		}		
	}
}
