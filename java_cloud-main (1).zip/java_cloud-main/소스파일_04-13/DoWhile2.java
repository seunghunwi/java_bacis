import java.util.Scanner;

public class DoWhile2 {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);		
					
		do {
			System.out.print("Input name [quit] ");
			String name = scan.nextLine();
			if (name.equals("quit")) {  //name == "quit" 
				break;
			}
			System.out.printf("����� �̸��� %s�Դϴ�.%n", name);
					
		} while (true);		
	}
}
