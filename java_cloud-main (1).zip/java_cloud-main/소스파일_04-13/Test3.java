
public class Test3 {
	
	public static void main(String[] args) {
		
		int num = 10;
		
		if (num % 2 == 0) {
			System.out.println("¦���Դϴ�.");
		} else {
			System.out.println("Ȧ���Դϴ�.");
		}
	}
	

}
