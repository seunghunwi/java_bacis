
public class For3 {

	public static void main(String[] args) {
		
		for (int i = 1; i < 10; i++) {
			System.out.printf("2 * %d = %d%n", i, (2 * i));
		}
	}

}
