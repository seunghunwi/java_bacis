
public class DataTypeConversion3 {

	public static void main(String[] args) {
		
		byte num1 = 5, num2 = 5;
		
		int result = num1 + num2;
		
		System.out.printf("result = %d", result);
		
		double num3 = 4.5;
		
		int num4 = 5;
		
		double result1 = num3 + num4;
		
		System.out.printf("result1 = %.1f", result1);
		
		
		String result3 = "result3 " + 1;
		

	}

}
