import java.util.Scanner;

public class For4 {

	public static void main(String[] args) {

		System.out.print("���� �Է��ϼ��� ");
		
		Scanner scan = new Scanner(System.in);
		int dan = scan.nextInt();
		

		for (int i = 1; i < 10; i++) {
			System.out.printf("%d * %d = %d%n", dan, i, (dan * i));
		}
	
	}

}
