
public class DataTypeConversion4 {

	public static void main(String[] args) {
		
		// String -- >> int
		
		String str = "12345";
		
		int result = Integer.parseInt(str);
		
		System.out.printf("result = %d%n", result + 1);
		
		System.out.printf("%s%n", str + 1);
	}

}
