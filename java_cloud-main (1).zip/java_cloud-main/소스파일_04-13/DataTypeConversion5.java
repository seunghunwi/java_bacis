
public class DataTypeConversion5 {

	public static void main(String[] args) {
		// String -->> double
		
		String str = "1234.56";
		double result = Double.parseDouble(str);
		System.out.printf("result = %.2f", result);
		

	}

}
