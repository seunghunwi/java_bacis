
public class Method6 {

	public static void hello(String name) {
		System.out.printf("Hello, %s!!", name);
		return;
	}
	
	public static void main(String[] args) {
		hello("�ϱ浿");
	}

}
