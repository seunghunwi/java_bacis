
public class Operator6 {

	public static void main(String[] args) {
		int num1 = 5, num2 = 10;
		
		int result = num1++ + num2;
		
		/*
		 * int result = num1 + num2;
		 * ++num1;   ���� ���� ������ 
		 */
		
		System.out.printf("result = %d, num1 = %d%n", result, num1);

	}

}
