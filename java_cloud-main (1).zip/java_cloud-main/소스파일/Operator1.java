
//��� �����ڿ� ���� ����

public class Operator1 {
	
	public static void main(String[] args) {
		
		int num1 = 10, num2 = 5;
		
		System.out.printf("%d + %d = %d%n", num1, num2, (num1 + num2));
		System.out.printf("%d - %d = %d%n", num1, num2, (num1 - num2));
		System.out.printf("%d * %d = %d%n", num1, num2, (num1 * num2));
		System.out.printf("%d / %d = %d%n", num1, num2, (num1 / num2));
		System.out.printf("%d %% %d = %d%n", num1, num2, (num1 % num2));
		
	
	}
	

}
