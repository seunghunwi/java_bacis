
public class DataType8 {
	
	public static void main(String[] args) {
		String name = "�ϱ浿";
		int age = 20;
		char gender = '��';
		boolean isMarried = false;
		double height = 180000.3;
		
		System.out.printf("�̸� : %s%n", name);
		System.out.printf("���� : %d%n", age);
		System.out.printf("���� : %c%n", gender);
		System.out.printf("��ȥ���� : %b%n", isMarried);
		System.out.printf("Ű : %,.1f%n", height);
		
		
	}
	

}
