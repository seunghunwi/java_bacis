
public class Operator7 {

	public static void main(String[] args) {
		int num = 5;
		
		System.out.printf("num = %d%n", num--);
		/*
		 * System.out.printf("num = %d%n", num); 
		 * num--;
		 */
		
		//System.out.printf("num = %d%n", --num);
		/*
		 * --num;
		 * System.out.printf("num = %d%n", num);		
		 */
		
	}

}
